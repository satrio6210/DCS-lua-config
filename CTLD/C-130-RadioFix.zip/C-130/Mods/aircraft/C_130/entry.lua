declare_plugin("C-130FR_Totoaero",
{
image     	 = "FC3.bmp",
installed 	 = true, -- if false that will be place holder , or advertising
dirName	  	 = current_mod_path,

fileMenuName = _("C-130FR"),
version		 = "1.2.14",
state		 = "installed",
info		 = _("C-130FR by totoaero"),

Skins	= 
	{
		{
			name	= "C-130FR",
			dir		= "Skins/1"
		},
	},
Missions =
	{
		{
			name		= _("C-130FR"),
			dir			= "Missions",
			CLSID		= "{BE17BAE1-A282-405E-9536-61AF644AB292}",	
            download	= "http://www.digitalcombatsimulator.com/en/downloads/video/fc3/",
			download_ru	= "http://www.digitalcombatsimulator.com/ru/downloads/video/fc3/"
		},
	},
	
LogBook =
	{
                {
			name		= _("C-130FR"),
			type		= "C-130FR",
	},
              
},

	--[[
Options =
	{
		{
			name		= _("C-130FR"),
			nameId		= "C-130FR",
			dir			= "Options",
			CLSID		= "{8A1FFFA5-D842-4EF8-8F65-EA9FDF40AC6E}"
		},
	},]]
	
InputProfiles =
{
    ["c-130FR"] = current_mod_path .. '/Input/c-130FR',
    
},

binaries 	 =
{
'FC3',
},


})
----------------------------------------------------------------------------------------
dofile(current_mod_path..'/C-130fr.lua')
dofile(current_mod_path.."/Views.lua")
make_view_settings('C-130FR', ViewSettings, SnapViews)

make_flyable('C-130FR', current_mod_path..'/Cockpit/',{nil,old = 6}, current_mod_path..'/comm.lua')

----------------------------------------------------------------------------------------
plugin_done()

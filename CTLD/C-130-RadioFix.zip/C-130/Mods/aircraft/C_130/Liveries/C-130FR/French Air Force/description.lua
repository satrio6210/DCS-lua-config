livery = {
	{"C-130_fusel", 0 ,"C-130_map_fus_FRA",true};
	{"C-130_wing", 0 ,"C-130_map_wings_FRA",true};
	{"C-130_wing_2", 0 ,"C-130_map_wings_2_FRA",true};
	{"C-130_notes", 0 ,"C-130_notes_empty",true};
	
}

countries = {"FRA"}
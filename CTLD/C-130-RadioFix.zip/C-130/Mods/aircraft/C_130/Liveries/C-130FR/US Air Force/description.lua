livery = {
	{"C-130_fusel", 0 ,"C-130_map_fus",true};
	{"C-130_wing", 0 ,"C-130_map_wings",true};
	{"C-130_wing_2", 0 ,"C-130_map_wings_2",true};
	{"C-130_notes", 0 ,"C-130_notes",true};
	
}

countries = {"USA"}
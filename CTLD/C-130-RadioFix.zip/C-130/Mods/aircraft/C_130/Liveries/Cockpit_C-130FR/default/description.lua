livery = 
{

	{"F-15C_Mirrors", 0 ,"mirrors",true};--mirrors texture replacement with runtime rendered one
}

ViewSettings = {
	Cockpit = {
	[1] = {-- player slot 1
		CockpitLocalPoint      = {6.000000,2.57000,0.0000000},
		CameraViewAngleLimits  = {75.000000,100.000000},
		CameraAngleRestriction = {true,60.000000,0.400000},
		CameraAngleLimits      = {120.000000,-45.000000,55.000000},
		EyePoint               = {0.0900000,0.000000,0.000000},
		limits_6DOF            = {x = {-10.000000,10.000000},y ={-3.0000,3.000000},z = {-3.000000,3.000000},roll = 0.000000},
	},
	}, -- Cockpit 
	Chase = {
		LocalPoint      = {1.220000,3.750000,0.000000},
		AnglesDefault   = {180.000000,-8.000000},
	}, -- Chase 
	Arcade = {
		LocalPoint      = {-15.080000,6.350000,0.000000},
		AnglesDefault   = {0.000000,-8.000000},
	}, -- Arcade 
}

SnapViews = {
[1] = {-- player slot 1
	[1] = {
		viewAngle = 100.0,--FOV
		hAngle	 = 0.0,
		vAngle	 = 0.00,
		x_trans	 = -0.10,
		y_trans	 = -0.074373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[2] = {
		viewAngle = 32.704346,--FOV
		hAngle	 = 25.696522,
		vAngle	 = -34.778103,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[3] = {
		viewAngle = 32.704346,--FOV
		hAngle	 = 0.000000,
		vAngle	 = -47.845268,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[4] = {
		viewAngle = 36.106045,--FOV
		hAngle	 = -28.878576,
		vAngle	 = -36.780628,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[5] = {
		viewAngle = 88.727844,--FOV
		hAngle	 = 128.508865,
		vAngle	 = 13.131046,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[6] = {
		viewAngle = 41.928593,--FOV
		hAngle	 = 0.000000,
		vAngle	 = -4.630446,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[7] = {
		viewAngle = 88.727844,--FOV
		hAngle	 = -128.508865,
		vAngle	 = 13.131046,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[8] = {
		viewAngle = 88.727844,--FOV
		hAngle	 = 81.648369,
		vAngle	 = -9.500000,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[9] = {--touchewindows8
		viewAngle = 100.000,--FOV
		hAngle	 = 0.000000,
		vAngle	 = -18.000,
		x_trans	 = 0.264295,
		y_trans	 = 0.000,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[10] = {
		viewAngle = 88.727844,--FOV
		hAngle	 = -80.997551,
		vAngle	 = -9.500000,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[11] = {--look at left  mirror
		viewAngle = 56.032040,--FOV
		hAngle	 = 14.803060,
		vAngle	 = 3.332499,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[12] = {--look at right mirror
		viewAngle = 56.032040,--FOV
		hAngle	 = -14.414484,
		vAngle	 = 3.332499,
		x_trans	 = 0.264295,
		y_trans	 = -0.064373,
		z_trans	 = 0.000000,
		rollAngle = 0.000000,
	},
	[13] = {--default view
		viewAngle = 90.000000,--FOV
		hAngle	 = 0.000000,
		vAngle	 = -8.000000,
		x_trans	 = 3.200000,
		y_trans	 = -1.20000,
		z_trans	 = -0.5500000,
		rollAngle = 0.000000,
	},
},
}